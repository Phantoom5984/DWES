<?php
/**
 * @author Sergio Salvago Medina
 */
// Ejercicio 13. Escribe una función que calcule A elevado a B, siendo A y B números enteros.
$a=ReadLine("Dime un número: ");
$b=ReadLine("Dime otro número: ");
$resultado=pow($a,$b);
echo ($resultado);
// Con estas líneas de código recojo dos números y con el "pow" hago la potencia.
?>