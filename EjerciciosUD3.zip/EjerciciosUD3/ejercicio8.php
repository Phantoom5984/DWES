<?php
/**
 * @author Sergio Salvago Medina
 */
// Ejercicio 8. Crea la tabla de multiplicar a partir de un número.
$numero=ReadLine("Dime un número: ");
for($i=1;$i<=10;$i++){
    echo ($numero*$i."\n");
}
// Con estas líneas de código recojo el número y con un for hago que se vaya multiplicando.
?>