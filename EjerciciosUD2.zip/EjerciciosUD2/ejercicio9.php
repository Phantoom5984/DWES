<?php
/**
 * @author Sergio Salvago Medina
 */
// Ejercicio 9. Dado un precio aleatorio entre 10 y 90, devolver mensaje “la cantidad es de “ indicando a continuación el número obtenido.
$numero=rand(10,90); // Con esta línea de código guardo en una variable un número aleatorio entre el 10 y el 90.
echo ("La cantidad es de: ".$numero); // Con esta línea de código hago un print del número que ha salido.
?>