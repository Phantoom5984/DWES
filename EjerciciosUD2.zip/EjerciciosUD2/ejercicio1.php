<?php
/**
 * @author Sergio Salvago Medina
 */
// Ejercicio 1. Pide un nombre, guárdalo en una variable y muestra un mensaje como “Hola Nombre, encantado de conocerte”.
$nombre = ReadLine("Hola dime tu nombre : "); // Con esta línea de código recojo el nombre que se escribe por teclado.
echo ("Hola $nombre, encantado de conocerte"); // Con esta línea de código hago un print con el nombre recogido anteriormente.
?>